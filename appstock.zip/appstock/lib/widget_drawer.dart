import 'package:flutter/material.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: ListView(
          children: [
            DrawerHeader(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        colors: [
                          Colors.black12,
                          Colors.lightBlueAccent,
                        ]
                    )
                ),
                child:Center(
                  child: CircleAvatar(
                    backgroundImage: AssetImage("assets/images/logooo.png"),
                    radius: 50,
                  ),
                )),
            ListTile(
              title: Text("Cartes Électroniques", style: TextStyle(fontSize: 26),),
              onTap: (){
                Navigator.of(context).pop(); //traj3k l page d'accuiel directement
                Navigator.pushNamed(context, "/Les Cartes ");

              },
            ),
            Divider(height: 5, color: Colors.black,),
            ListTile(
              title: Text("Piles", style: TextStyle(fontSize: 26),),
              onTap: (){
                Navigator.of(context).pop(); //traj3k l page d'accuiel directement
                Navigator.pushNamed(context, "/Les piles");
              },
            ),
            Divider(height: 5, color: Colors.black,),
            ListTile(
              title: Text("Moteurs", style: TextStyle(fontSize: 26),),
              onTap: (){
                Navigator.of(context).pop(); //traj3k l page d'accuiel directement
                Navigator.pushNamed(context, "/mouteur");

              },
            )
          ],
        )






    );
  }
}
