import 'package:appstock/Categories/addcategorie.dart';
import 'package:appstock/Categories/listcategorie.dart';
import 'package:appstock/carte.dart';
import 'package:appstock/home.dart';
import 'package:appstock/materiels/addMteriel.dart';
import 'package:appstock/materiels/listMateriel.dart';
import 'package:appstock/materiels/listmembre.dart';
import 'package:appstock/mouteurs.dart';
import 'package:appstock/pile.dart';
import 'package:flutter/material.dart';


void main() {
  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        "/home": (context) {
          return LoginDemo();
        },
        "/Les Cartes ": (context) => Carte(),

        "/Les piles": (context) => Pile(),

       "/mouteur":(context)=>Mouteur(),

        "/ajouterMateriel":(context)=>Add(),
        "/ajouterCategorie":(context)=>AddCategorie(),
        "/La liste des Materiels":(context)=>ListMateriel(),
        "/La liste des categories":(context)=>ListCategorie(),
        "/La liste des Membres":(context)=>ListMember()

},
        theme: ThemeData(
        primarySwatch: Colors.lightGreen
        ),
        initialRoute: "/home",

    );
  }
}


