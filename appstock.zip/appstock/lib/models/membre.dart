class Membre {
  int? id;
  String? nom;
  String? prenom;
  int? phone1;
  int? qte;
  int? idMaterial;
  String? state;
  DateTime? dateReturn;
  Membre(
      {required this.id,
        required this.nom,
        required this.prenom,
        required this.phone1,
        required this.idMaterial,
        required this.qte,
        required this.state,
        required this.dateReturn});

  Map<String, dynamic> toMap() {
    return {
      'firstName': nom,
      'lastName': prenom,
      'phoneNumber1': phone1,
      'qte': qte,
      'idMaterial': idMaterial,
      'state': state,
      'dateReturn':
      dateReturn != null ? dateReturn!.microsecondsSinceEpoch : null
    };
  }

  static Membre fromMap(Map<String, dynamic> json) {
    return Membre(
      id: json['id'],
      nom: json['nom'],
      prenom: json['prenom'],
      phone1: json['phone1'],
      qte: json['qte'],
      idMaterial: json['idMaterial'],
      state: json['state'],
      dateReturn: json['dateReturn'] != null
          ? DateTime.fromMicrosecondsSinceEpoch(json['dateReturn'])
          : null,
    );
  }
}
