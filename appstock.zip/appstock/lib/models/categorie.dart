class Categorie {
  String? categname;
  Categorie({required this.categname});

  Map<String, dynamic> toMap(){
    return{
      'categname':categname,
  };
}

static Categorie fromMap(Map<String, dynamic> json){
    return Categorie(categname: json['categname'],);
}

}