class Materiel {
  int? id;
  String? nomMateriel;
  int? qte;
  DateTime? dateAcqui;
  String? nomC;
  Materiel({
    required this.id,
    required this.nomMateriel,
    required this.qte,
    required this.dateAcqui,
    required this.nomC,
  });
  Materiel.create(this.nomMateriel, this.qte, this.dateAcqui, this.nomC);

  Map<String, dynamic> toMap() {
    return {
      'nomMateriel': nomMateriel,
      'quantite': qte,
      'dateAcquisition': dateAcqui!.microsecondsSinceEpoch,
      'nomF': nomC,
    };
  }

  static Materiel fromMap(Map<String, dynamic> json) {
    return Materiel(
      id: json['id'],
      nomMateriel: json['nomMateriel'],
      qte: json['qte'],
      dateAcqui: DateTime.fromMicrosecondsSinceEpoch(json['dateAcquisition']),
      nomC: json['nomC'],
    );
  }
}
