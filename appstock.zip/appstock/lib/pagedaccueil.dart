import 'package:appstock/Categories/addcategorie.dart';
import 'package:appstock/materiels/addMteriel.dart';
import 'package:appstock/widget_drawer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class Accueil extends StatefulWidget {
  const Accueil({Key? key}) : super(key: key);

  @override
 State<Accueil> createState() => _AccueilState();
}

class _AccueilState extends State<Accueil> {
  TextEditingController textController = TextEditingController();
  String? nomMateriel;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyDrawer(),
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text("Welcome to iStore"),
      ),
    body: SingleChildScrollView(
      child: Column(
        children: <Widget>[
      Padding(
      padding: const EdgeInsets.only(top: 60.0),
      child: Center(
        child: Text(
          "Hello User",
          textAlign: TextAlign.center,
        ),
      ),
    ),
          Padding(
            padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 50.0),
            child: Text(
              "Ajouter Une Categorie",
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 50.0),
            child:FlatButton(
              onPressed: () => {
                Navigator.push(
                    context, MaterialPageRoute(builder: (_) => AddCategorie())),
              },
              color: Colors.blue,
              padding: EdgeInsets.all(10.0),
              child: Column(
                children: [
                  Icon(Icons.add),
                ],
              ),
            ),
          ),



    ]
),
      ),
    );

    }


  }
