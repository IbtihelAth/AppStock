import 'package:appstock/materiels/addMteriel.dart';
import 'package:appstock/mouteurbleu.dart';
import 'package:flutter/material.dart';

class Mouteur extends StatefulWidget {
  const Mouteur({Key? key}) : super(key: key);

  @override
  _MouteurState createState() => _MouteurState();
}

class _MouteurState extends State<Mouteur> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text("Nos Mouteurs"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 20.0),
              child: Text(
                "Ajouter Des Materiels",
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 20.0),
              child:FlatButton(
                onPressed: () => {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => Add())),
                },
                color: Colors.blue,
                padding: EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    Icon(Icons.add),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                    child: Image.asset('assets/images/mouteurbleu.jpg' ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>MBleu()),);
                    },
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:15.0,bottom: 0),
              child: Center(
                child: Text('Moteur électrique 2,2KW/3CV'),
              ),
            ),

          ],
        ),
      ),




    );
  }
}

