import 'package:appstock/DataBase/categorieservice.dart';
import 'package:appstock/DataBase/dg.dart';
import 'package:flutter/material.dart';
import 'package:appstock/models/categorie.dart';

class AddCategorie extends StatefulWidget {
  const AddCategorie({Key? key}) : super(key: key);

  @override
  _AddCategorieState createState() => _AddCategorieState();
}

class _AddCategorieState extends State<AddCategorie> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? categname;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          TextFormField(
            decoration: const InputDecoration(
              hintText: 'Entrer un nom',
            ),
            validator: (String? value) {
              if (value == null || value.isEmpty) {
                return 'text non valide';
              }

              setState(() {
                categname = value;
              });
            },
          ),
          ElevatedButton(
            child: const Text('add'),
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                bool state =
                await CategorieService.add(Categorie(categname: categname));
                await MyDialog.fullDialog(
                    context, state ? "INSERT SUCCESS" : "Categorie EXISTS");
                CategorieService.getAllFamily();
                if (state) {
                  Navigator.pushNamed(context, '/listCategorie');
                }
              }
            },
          ),
        ],
      ),
    );
  }
}
