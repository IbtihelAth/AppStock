import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';

class Categorie extends StatefulWidget {
  const Categorie({Key? key}) : super(key: key);

  @override
  _CategorieState createState() => _CategorieState();
}

class _CategorieState extends State<Categorie> {
  final GlobalKey<NavigatorState> key=GlobalKey();
  ValueNotifier<bool> Dial=ValueNotifier(false);
  @override
  Widget build(BuildContext context) {
    return WillPopScope(

      onWillPop: () async {
        if (Dial.value) {
          Dial.value = false;
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
          floatingActionButton: SpeedDial(
            animatedIcon: AnimatedIcons.menu_close,
            openCloseDial: Dial,
            backgroundColor: Colors.blueAccent,
            overlayColor: Colors.grey,
            overlayOpacity: 0.5,
            spacing: 15,
            spaceBetweenChildren: 15,
            closeManually: true,
            children: [
              SpeedDialChild(
                  child: const Icon(Icons.list),
                  label: 'List Family',
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  onTap: () {
                    setState(() {
                      Dial.value = false;
                    });
                    key.currentState!.pushNamed('/listFamily');
                  }),
              SpeedDialChild(
                  child: const Icon(Icons.add),
                  label: 'Add Family',
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  onTap: () {
                    setState(() {
                      Dial.value = false;
                    });
                    key.currentState!.pushNamed('/addFamily');
                  }),
            ],
          )),
    );
  }
}


