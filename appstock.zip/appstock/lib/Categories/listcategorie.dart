import 'package:appstock/DataBase/categorieservice.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:appstock/models/categorie.dart';


class ListCategorie extends StatefulWidget {
  const ListCategorie({Key? key}) : super(key: key);

  @override
  _ListCategorieState createState() => _ListCategorieState();
}

class _ListCategorieState extends State<ListCategorie> {
  String? nomC;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(

        future: CategorieService.getAllFamily(),
        builder:
            (BuildContext context, AsyncSnapshot<List<Categorie>> projectSnap) {
          if (projectSnap.connectionState == ConnectionState.none ||
              !projectSnap.hasData) {
            return const Text("NO DATA");
          }
          return ListView.builder(
              itemCount: projectSnap.data!.length,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    Card(
                      elevation: 8,
                      margin: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          ListTile(
                            leading: const Icon(Icons.album, size: 48),
                            title: Text(projectSnap.data![index].categname!,
                                style: const TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.w600)),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: <Widget>[
                              TextButton(
                                child: const Text('view material'),
                                onPressed: () {},
                              ),
                              const SizedBox(width: 8),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              });
        });
  }
}

