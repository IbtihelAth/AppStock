import 'package:appstock/materiels/addMteriel.dart';
import 'package:appstock/modeleduracel.dart';
import 'package:appstock/modelevarta.dart';
import 'package:flutter/material.dart';

class Pile extends StatefulWidget {
  const Pile({Key? key}) : super(key: key);

  @override
  _PileState createState() => _PileState();
}

class _PileState extends State<Pile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text("Nos Piles"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 20.0),
              child: Text(
                "Ajouter Des Materiels",
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 20.0),
              child:FlatButton(
                onPressed: () => {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => Add())),
                },
                color: Colors.blue,
                padding: EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    Icon(Icons.add),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                    child: Image.asset('assets/images/pile1.jpg' ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>Duracelll()),);
                    },
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:15.0,bottom: 0),
              child: Center(
                child: Text('Duracell'),
              ),
            ),


            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                    child: Image.asset('assets/images/vaarta.jpg' ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>Varta()),);
                    },
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:15.0,bottom: 0),
              child: Center(
                child: Text('Varta'),
              ),
            ),



          ],
        ),
      ),


    );
  }
}

