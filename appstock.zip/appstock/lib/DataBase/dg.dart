import 'package:appstock/models/membre.dart';
import 'package:flutter/cupertino.dart';
import 'package:appstock/materiels/materiel.dart';
import 'package:appstock/models/materiel.dart';
import 'package:appstock/DataBase/materielservice.dart';
import 'package:flutter/material.dart';


class MyDialog {
  static Future<void> fullDialog(BuildContext context, String message) {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: const Text("MESSAGE"),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              elevation: 16,
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[Text(message)],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context, 'Cancel'),
                  child: const Text('OK'),
                ),
              ]);
        });
  }

  static Future<DateTime?> dateDialog(BuildContext context) {
    return showDialog<DateTime>(
      context: context,
      builder: (BuildContext context) {
        return DatePickerDialog(
          initialDate: DateTime.now(),
          firstDate: DateTime(2000),
          lastDate: DateTime.now(),
          confirmText: "Procced",
        );
      },
    );
  }

  static Future<void> detailMaterial(BuildContext context, Materiel mat) {
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text("Detail : " + mat.nomMateriel!),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              elevation: 16,
              content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[
                    Text("family name :" + mat.nomC!,
                        style:
                        const TextStyle(fontSize: 18, color: Colors.grey)),
                    Text("Quantity : " + mat.qte.toString(),
                        style:
                        const TextStyle(fontSize: 18, color: Colors.grey)),
                    Text("dateAcquition : " + mat.dateAcqui.toString(),
                        style:
                        const TextStyle(fontSize: 18, color: Colors.grey))
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context, 'Cancel'),
                  child: const Text('OK'),
                ),
              ]);
        });
  }

  static Future<void> borrowMaterialForm(BuildContext context, Materiel mat) {
    final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
    String? nom;
    String? prenom;
    String? phone1;
    String? qte;
    return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          if (mat.qte! < 1) {
            return const AlertDialog(
              content: Text("No Quatity left"),
            );
          }
          return StatefulBuilder(builder: (context, setState) {
            return AlertDialog(
              content: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextFormField(
                        decoration: const InputDecoration(
                          hintText: 'Enter First Name',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'you must enter your first name';
                          }
                          setState(() {
                            nom = value;
                          });
                        },
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          hintText: 'Enter Last Name',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'you must enter your last name';
                          }
                          setState(() {
                            prenom = value;
                          });
                        },
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          hintText: 'Enter Phone number',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'you must enter your phone number';
                          }
                          setState(() {
                            phone1 = value;
                          });
                        },
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          hintText: 'Enter Quantity',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'you must enter meterial quantity';
                          }

                          if (int.parse(value) > mat.qte!) {
                            return 'max quantity is ' + mat.qte.toString();
                          }
                          setState(() {
                            qte = value;
                          });
                        },
                      ),
                    ],
                  )),
              title: Text('Borrow :' + mat.nomMateriel!),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context, 'Cancel'),
                  child: const Text('Cancel'),
                ),

              ],
            );
          });
        });
  }

  static Future<void> returnMaterialForm(BuildContext context, Membre mem) {
    final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
    DateTime? dateR;
    String? etat;
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(40)),
              elevation: 16,
              content: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      DropdownButton<String>(
                        value: etat,
                        iconSize: 24,
                        elevation: 16,
                        hint: const Text("Enter State"),
                        style: const TextStyle(color: Colors.black),
                        underline: Container(
                          height: 2,
                          color: Colors.blue,
                        ),
                        onChanged: (String? newValue) {
                          setState(() {
                            etat = newValue!;
                          });
                        },
                        items: <String>[
                          'endommagé',
                          'gravement endomagé',
                          'intact'
                        ].map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                      ),
                      ElevatedButton(
                          onPressed: () async {
                            DateTime? date = await MyDialog.dateDialog(context);
                            setState(() {
                              dateR = date;
                            });
                          },
                          child: const Text("Enter date Retour")),
                    ],
                  )),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context, 'Cancel'),
                  child: const Text('Cancel'),
                ),
              ],
            );
          });
        });
  }
}
