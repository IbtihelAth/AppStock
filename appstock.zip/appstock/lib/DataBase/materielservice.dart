import 'package:appstock/models/materiel.dart';
import 'package:appstock/DataBase/connexion.dart';
import 'package:appstock/models/membre.dart';
import 'package:sqflite/sqflite.dart';


class Materielservice {
  static Future<bool> add(Materiel mat) async {
    Database db = await Stockdatabase.getDatabase();
    List<Map> material = await db.query("Materiel",
        where: "nomMateriel=? and qte=? and dateAcqui=? and nomC=?",
        whereArgs: [
          mat.nomMateriel,
          mat.qte,
          mat.dateAcqui!.microsecondsSinceEpoch,
          mat.nomC
        ]);
    if (material.isEmpty) {
      await db.insert("Materiel", mat.toMap());
      return true;
    }
    return false;
  }

  static Future<List<Materiel>> getAllMaterial() async {
    Database db = await Stockdatabase.getDatabase();
    List<Map<String, Object?>> mapMaterial = await db.query("Materiel");
    List<Materiel> allMaterial = [];
    mapMaterial
        .forEach((element) => allMaterial.add(Materiel.fromMap(element)));
    return allMaterial;
  }

  static Future<List<Membre>> getAllMember() async {
    Database db = await Stockdatabase.getDatabase();
    List<Map<String, Object?>> mapMembers = await db.query("MEMBERS");
    List<Membre> allMembers = [];
    mapMembers.forEach((element) => allMembers.add(Membre.fromMap(element)));
    return allMembers;
  }


  static Future<Materiel> getMaterialById(int id) async {
    Database db = await Stockdatabase.getDatabase();
    List<Map<String, Object?>> map =
    await db.query("Materiel", where: "id = ?", whereArgs: [id]);
    return Materiel.fromMap(map.first);
  }

  static Future<List<Materiel>> getMaterialByNomF(String nomC) async {
    Database db = await Stockdatabase.getDatabase();
    List<Map<String, dynamic>> materials =
    await db.query("Materiel", where: "nomC = ?", whereArgs: [nomC]);
    List<Materiel> allMaterial = [];
    materials.forEach((element) => allMaterial.add(Materiel.fromMap(element)));
    return allMaterial;
  }

}
