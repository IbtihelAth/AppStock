

import 'package:appstock/models/categorie.dart';
import 'package:appstock/DataBase/connexion.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite/sqlite_api.dart';

class CategorieService{
  static Future<bool> add(Categorie categ)async{
  Database db=await Stockdatabase.getDatabase();
  List<Map> categorie = await db
      .query("Categorie", where: "categname = ?", whereArgs: [categ.categname]);
  if (categorie.isEmpty) {
  print(categ.toMap());
  await db.insert("Categorie", categ.toMap());
  return true;
  }
  return false;
}

  static Future<List<Categorie>> getAllFamily() async {
 Database db = await Stockdatabase.getDatabase();
 List<Map<String, Object?>> mapcateg = await db.query("Categorie");
 List<Categorie> allFamilly = [];
 mapcateg.forEach((element) => allFamilly.add(Categorie.fromMap(element)));
 return allFamilly;
}
}