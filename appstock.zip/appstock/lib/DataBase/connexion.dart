import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';


class Stockdatabase {
  static const databaseName = "Stock.db";
  static const databaseVersion = 1;
  static Database? _database;

  static Future<Database> getDatabase() async {
    return _database ??= await initDatabase();
  }

  static Future<Database> initDatabase() async {
    String documentDirectory = await getDatabasesPath();
    String path = join(documentDirectory, databaseName);
    return await openDatabase(path,
        version: databaseVersion, onCreate: _onCreate);
  }

  static Future _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE Categorie (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      categname TEXT NOT NULL
      )
      ''');
    await db.execute('''CREATE TABLE Materiel (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nomMateriel TEXT NOT NULL,
      qte INTEGER  NOT NULL,
      dateAcqui INTEGER,
      dateRetour INTEGER,
      nomC TEXT NOT NULL,
      FOREIGN KEY(nomC) REFERENCES Categorie(categname)
      )
      ''');
    await db.execute(''' CREATE TABLE Membres(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT NOT NULL,
      prenom TEXT NOT NULL,
      phone1 INTEGER NOT NULL,
      qteMembre INTEGER NOT NULL,
      idMaterial INTEGER,
      state TEXT,
      dateReturn INTEGER,
      FOREIGN KEY(idMaterial) REFERENCES Materiel(id)
      )
    ''');
  }
}


