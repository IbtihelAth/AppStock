import 'package:appstock/STM.dart';
import 'package:appstock/arduino.dart';
import 'package:appstock/materiels/addMteriel.dart';
import 'package:appstock/unor.dart';
import 'package:flutter/material.dart';
import 'package:appstock/ESP.dart';
class Carte extends StatefulWidget {
  const Carte({Key? key}) : super(key: key);

  @override
  _CarteState createState() => _CarteState();
}

class _CarteState extends State<Carte> {


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text("Nos Cartes"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 20.0),
                child: Text(
                  "Ajouter Des Materiels",
                  textAlign: TextAlign.center,
                ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:90.0,right: 10.0,top: 20.0),
                  child:FlatButton(
                    onPressed: () => {
                      Navigator.push(
                          context, MaterialPageRoute(builder: (_) => Add())),
                    },
                    color: Colors.blue,
                    padding: EdgeInsets.all(10.0),
                    child: Column(
                      children: [
                        Icon(Icons.add),
                      ],
                    ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(top: 60.0),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                  child: Image.asset('assets/images/ESP32.jpg' ),
                    onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) =>Esp()),);
                    },
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:15.0,bottom: 0),
              child: Center(
                child: Text('ESP32'),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:30.0,bottom: 0),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                  child: Image.asset('assets/images/unor2.jpg' ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>Unor()),);
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:30.0,bottom: 0),
              child: Center(
                child: Text('UNOR2'),
              ),
            ),


            Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15.0, top: 30.0, bottom: 0),
              //padding: EdgeInsets.symmetric(horizontal: 15),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                  child: Image.asset('assets/images/STM32F407.jpg' ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>STM()),);
                    },),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:30.0,bottom: 0),
              child: Center(
                child: Text('STM32F407'),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:30.0,bottom: 0),
              child: Center(
                child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                  child:ElevatedButton(
                    child: Image.asset('assets/images/Arduino.jpg' ),
                    onPressed: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) =>Arduino()),);
                    },
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left:15.0,right: 15.0,top:30.0,bottom: 50.0),
              child: Center(
                child: Text('Arduino Mega'),
              ),
            ),




          ],
        ),
      ),




    );
  }
}

