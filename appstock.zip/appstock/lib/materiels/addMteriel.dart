import 'package:appstock/DataBase/categorieservice.dart';
import 'package:appstock/DataBase/dg.dart';
import 'package:appstock/DataBase/materielservice.dart';
import 'package:flutter/material.dart';
import 'package:appstock/materiels/materiel.dart';
import 'package:appstock/models/categorie.dart';
import 'package:appstock/models/materiel.dart';

class Add extends StatefulWidget {
  const Add({Key? key}) : super(key: key);

  @override
  _AddState createState() => _AddState();
}

class _AddState extends State<Add> {
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  String? nomMateriel;
  int? qte;
  DateTime? dateAqui;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(

        key: _formkey,
        child: FutureBuilder<List<Categorie>>(
          future: CategorieService.getAllFamily(),
          builder:
              (BuildContext context, AsyncSnapshot<List<Categorie>> snapshot) {
            Widget children;
            if (snapshot.hasData) {
              children = DropdownButton<String>(
                value: nomMateriel,
                icon: const Icon(Icons.arrow_downward),
                iconSize: 24,
                hint: const Text("CHOOSE Categorie"),
                elevation: 16,
                style: const TextStyle(color: Colors.blueGrey),
                underline: Container(
                  height: 2,
                  color: Colors.blueGrey,
                ),
                items: snapshot.data!.map<DropdownMenuItem<String>>((e) {
                  return DropdownMenuItem<String>(
                    alignment: AlignmentDirectional.center,
                    value: e.categname,
                    child: Text(e.categname!),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    nomMateriel = value;
                  });
                },
              );
            } else {
              children = const Text('Categorie NOT FOUND');
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter name',
                  ),
                  validator: (String? value) {
                    if (value == null || value.isEmpty) {
                      return 'Please try again';
                    }
                    setState(() {
                      nomMateriel = value;
                    });
                  },
                ),
                TextFormField(
                  decoration: const InputDecoration(
                    hintText: 'Enter quantite',
                  ),
                  validator: (String? value) {
                    if (value == null) {
                      return 'Please enter some text';
                    }
                    setState(() {
                      qte = int.parse(value);
                    });
                  },
                ),
                ElevatedButton(
                    onPressed: () async {
                      DateTime? date = await MyDialog.dateDialog(context);
                      setState(() {
                        dateAqui = date;
                      });
                    },
                    child: const Text("Date d'acquition")),
                children,
                ElevatedButton(
                  child: const Text('add'),
                  onPressed: () async {
                    if (_formkey.currentState!.validate()) {
                      bool state = await Materielservice.add(
                          Materiel.create(nomMateriel, qte, dateAqui, nomMateriel));
                      state
                          ? MyDialog.fullDialog(context, "MATERIAL ADDED")
                          : MyDialog.fullDialog(context, "ERROR");
                    }
                  },
                ),
              ],
            );
          },
        )

    );
  }
}
