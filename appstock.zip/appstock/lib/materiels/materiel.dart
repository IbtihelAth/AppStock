import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';

class MyMateriel extends StatefulWidget {
  const MyMateriel({Key? key}) : super(key: key);

  @override
  _MyMaterielState createState() => _MyMaterielState();
}

class _MyMaterielState extends State<MyMateriel> {
  final GlobalKey<NavigatorState> key = GlobalKey();
  ValueNotifier<bool> Dial = ValueNotifier(false);
  @override
  Widget build(BuildContext context) {
    return WillPopScope(

      onWillPop: () async {
        if (Dial.value) {
          Dial.value = false;
          return false;
        } else {
          return true;
        }
      },
      child: Scaffold(
          floatingActionButton: SpeedDial(
            animatedIcon: AnimatedIcons.menu_close,
            openCloseDial: Dial,
            backgroundColor: Colors.blueAccent,
            overlayColor: Colors.grey,
            overlayOpacity: 0.5,
            spacing: 15,
            spaceBetweenChildren: 15,
            closeManually: true,
            children: [
              SpeedDialChild(
                  child: const Icon(Icons.list),
                  label: 'List Material',
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  onTap: () {
                    setState(() {
                      Dial.value = false;
                    });
                    key.currentState!.pushNamed('/listMaterial');
                  }),
              SpeedDialChild(
                  child: const Icon(Icons.add),
                  label: 'Add Material',
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  onTap: () {
                    setState(() {
                      Dial.value = false;
                    });
                    key.currentState!.pushNamed('/addMaterial');
                  }),
            ],
          )),
    );
  }
}

